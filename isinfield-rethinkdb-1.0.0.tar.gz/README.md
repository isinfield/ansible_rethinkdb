# MCP Snapshot Management and Reporting using Ansible

This collection contains a modules supporting RethinkDB

**Author:** Ken Sinfield <@isinfield>

## Requirements

### Ansible Version

* >2.9

### Python Modules

* rethinkdb

To install these modules execute:

> pip install --user rethinkdb
